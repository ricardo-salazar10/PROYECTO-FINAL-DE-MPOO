//
//  SecondaryViewController.swift
//  Proyecto2
//
//  Created by:
//  - Salazar Olivares Ricardo
//  - Yonatan Martín Galicia Serrano
//  on 14/11/24.
//

import UIKit

class SecondaryViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var myTableView: UITableView!
    
    var productsInCart:[ProductInfo] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(updateTable(_:)), name: notificationName, object: nil)
    }
    
    @objc func updateTable(_ notification: Notification) {
        if let product = notification.object as? ProductInfo {
            productsInCart.append(product)
        }
        tableView.reloadData()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}

extension SecondaryViewController:UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productsInCart.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cartCell", for: indexPath)
        let product = productsInCart[indexPath.row]
        
        cell.imageView?.image = product.productImage
        cell.textLabel?.text = product.productName
        
        return cell
    }
}

