//
//  ProductInfo.swift
//  Proyecto2
//
//  Created by:
//  - Salazar Olivares Ricardo
//  - Yonatan Martín Galicia Serrano
//  on 14/11/24.
//

import Foundation
import UIKit


class ProductInfo: Identifiable {
    var id:String
    let productImage:UIImage
    let productName:String
    
    init(imageName:String, name:String) {
        self.id = UUID().uuidString
        self.productImage = UIImage(named: imageName)!
        self.productName = name
    }
    
    init(image:UIImage, name:String) {
        self.id = UUID().uuidString
        self.productImage = image
        self.productName = name
    }
    
    init() {
        self.id = "Default"
        self.productImage = UIImage(named: "defaultImage")!
        self.productName = "Default product"
    }
}
