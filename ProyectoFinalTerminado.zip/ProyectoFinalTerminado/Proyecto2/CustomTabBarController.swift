//
//  CustomViewController.swift
//  Proyecto2
//
//  Created by Alumno on 15/11/24.
//

import UIKit

class ModelData {
    var cloudList:[ProductInfo] = []
}

class CustomTabBarController: UITabBarController {
    

    var model = ModelData()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
