//
//  MainViewController.swift
//  Proyecto2
//
//  Created by:
//  - Salazar Olivares Ricardo
//  - Yonatan Martín Galicia Serrano
//  on 14/11/24.
//

import UIKit

let notificationName = Notification.Name(rawValue: "addProductToCartTable")

class MainViewController: UIViewController {
    
    @IBAction func addToCartAction(_ sender: Any) {
        if productInDetail.id != ProductInfo().id {
            self.addProductToCart(product: productInDetail)
            self.plusBadge()
        }
    }
    @IBOutlet weak var productDetailImage: UIImageView!
    @IBOutlet weak var productDetailName: UILabel!
    
    var productsInfo:[ProductInfo] = [
        ProductInfo(imageName: "item1", name: "Taladro"),
        ProductInfo(imageName: "item2", name: "Sierra de mano"),
        ProductInfo(imageName: "item3", name: "Caja de Herramientas"),
        ProductInfo(imageName: "item4", name: "Sierra de mesa"),
        ProductInfo(imageName: "item5", name: "Mancuernas")]
    var productInDetail:ProductInfo = ProductInfo()
    var tabBadge = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setProductDetail(selectedProduct: productInDetail)
    }
    
    func setProductDetail(selectedProduct:ProductInfo) {
        productInDetail = selectedProduct
        productDetailImage.image = productInDetail.productImage
        productDetailName.text = productInDetail.productName
    }
    
    func addProductToCart(product: ProductInfo) {
        NotificationCenter.default.post(name: notificationName, object: product)
    }
    
    func plusBadge() {
        let tabBar = self.tabBarController!.tabBar
        let downloadItem = tabBar.items![0]
        downloadItem.badgeColor = UIColor.red
        downloadItem.badgeValue = "\(tabBadge)"
        self.tabBadge += 1
    }
}

extension MainViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return productsInfo.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! MyCollectionViewCell
        let product = productsInfo[indexPath.row]
        cell.productImageCell.image = product.productImage
        cell.productNameCell.text = product.productName
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let product = productsInfo[indexPath.row]
        self.setProductDetail(selectedProduct: product)
    }
}
